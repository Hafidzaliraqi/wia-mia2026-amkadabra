// HALAMAN PENGADUAN TUNTAS (/pengaduan-tuntas)
// Bagian: banner angka gelap → kartu "Jejak penyelesaian di daerah" (klik untuk filter) → tabel laporan selesai
// (cari, filter wilayah/kategori/periode, pagination) → sorotan kisah sukses → ajakan membuat pengaduan.
import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Reveal from '../components/Reveal.jsx'
import Photo from '../components/Photo.jsx'
import { Select, StatusBadge } from '../components/Common.jsx'
import { PinIcon, SearchIcon, CalendarIcon, ArrowIcon, CameraIcon, CheckCircleIcon } from '../components/Icons.jsx'
import { REGIONS, REPORTS, CATEGORIES, fmt } from '../data.js'

const PER_PAGE = 6
const TOTAL_PAGES = 320 // total simulasi 1.920 laporan ÷ 6 per halaman

export default function Resolved() {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const [region, setRegion] = useState('')
  const [cat, setCat] = useState('')
  const [page, setPage] = useState(1)

  const filtered = useMemo(() => {
    const k = q.trim().toLowerCase()
    return REPORTS.filter((r) =>
      (!region || r.region === region) &&
      (!cat || r.cat === cat) &&
      (!k || r.title.toLowerCase().includes(k) || r.id.toLowerCase().includes(k))
    )
  }, [q, region, cat])

  const isFiltering = q || region || cat
  const pages = isFiltering ? Math.max(1, Math.ceil(filtered.length / PER_PAGE)) : TOTAL_PAGES
  const shown = isFiltering ? filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE) : REPORTS.slice(0, PER_PAGE)
  const onFilter = (fn) => (v) => { fn(v); setPage(1) }

  // Nomor pagination yang ditampilkan: 1 2 3 … terakhir
  const pageNums = pages <= 5 ? Array.from({ length: pages }, (_, i) => i + 1) : [1, 2, 3, '…', pages]

  return (
    <main className="page">
      <div className="container">
        <Reveal className="page-head" style={{ paddingBottom: 0 }}>
          <p className="crumb"><Link to="/">Beranda</Link> / Pengaduan tuntas</p>
          <div className="data-head">
            <div>
              <p className="eyebrow">Bukan sekadar status</p>
              <h1 className="h1">Tuntas. Terlihat hasilnya.</h1>
              <p className="lead">Temukan laporan yang sudah selesai, daerah yang bergerak, dan perubahan yang dirasakan warga.</p>
            </div>
            <div className="sim-note"><span className="pill">Data simulasi</span><p>Jan–Sep 2026 · 6 daerah ilustratif. Bukan data resmi pemerintah.</p></div>
          </div>
        </Reveal>

        {/* Banner angka */}
        <Reveal className="banner-dark">
          <div><strong>1.920</strong><small>pengaduan sudah tuntas</small></div>
          <div className="mid"><strong>80%</strong><small>dari 2.400 laporan masuk</small></div>
          <p>Tuntas berarti ada penanganan, ada bukti, dan ada konfirmasi. Lihat hasilnya, bukan hanya angkanya.</p>
        </Reveal>

        {/* Kartu per daerah */}
        <div className="sec-head">
          <h2>Jejak penyelesaian di daerah</h2>
          <Link className="link" to="/statistik">Bandingkan di statistik <ArrowIcon size={13} /></Link>
        </div>
        <div className="region-cards">
          {REGIONS.map((r, i) => (
            <Reveal key={r.name} delay={i * 60}>
              <button className={`card rc ${region === r.name ? 'on' : ''}`} onClick={() => onFilter(setRegion)(region === r.name ? '' : r.name)} aria-pressed={region === r.name}>
                <span className="nm"><PinIcon size={13} />{r.name}</span>
                <strong>{r.done}</strong>
                <small>tuntas dari {r.in} laporan</small>
                <div className="track"><i style={{ width: '80%', animationDelay: `${i * 80}ms` }} /></div>
                <em>80% terselesaikan</em>
              </button>
            </Reveal>
          ))}
        </div>

        {/* Daftar laporan */}
        <div className="sec-head">
          <h2>Laporan selesai, kabar baik bersama.</h2>
          <span className="small muted">Urutkan: Terbaru selesai ↓</span>
        </div>
        <Reveal className="card search-bar">
          <div className="field">
            <label htmlFor="r-q">Cari laporan</label>
            <div className="input-wrap">
              <input id="r-q" className="input" placeholder="Judul atau nomor pengaduan" value={q} onChange={(e) => onFilter(setQ)(e.target.value)} />
              <span className="input-icon"><SearchIcon /></span>
            </div>
          </div>
          <Select id="r-region" label="Wilayah" value={region} onChange={onFilter(setRegion)} options={REGIONS.map((r) => r.name)} placeholder="Semua wilayah" />
          <Select id="r-cat" label="Kategori" value={cat} onChange={onFilter(setCat)} options={CATEGORIES.map((c) => c.key)} placeholder="Semua kategori" />
          <div className="field">
            <label htmlFor="r-period">Periode selesai</label>
            <div className="input-wrap">
              <input id="r-period" className="input" value="Jan–Sep 2026" readOnly />
              <span className="input-icon"><CalendarIcon /></span>
            </div>
          </div>
        </Reveal>

        <Reveal className="card table">
          <div className="thead"><span>Laporan &amp; kategori</span><span>Wilayah</span><span>Hasil penyelesaian</span><span>Status &amp; tanggal</span></div>
          {shown.length === 0 && <p className="empty">Belum ada laporan tuntas yang cocok. Coba kata kunci atau filter lain.</p>}
          {shown.map((r) => (
            <button className="trow" key={r.id} onClick={() => navigate(`/cari-laporan?q=${encodeURIComponent(r.title.split(' ')[0])}`)}>
              <div><span className="id">{r.id} · {r.cat}</span><span className="ttl">{r.title}</span><span className="dur">Selesai dalam {r.days} hari</span></div>
              <span>{r.region}</span>
              <span className="res">{r.result.split('. ')[0].replace(/\.$/, '')}.</span>
              <div className="st"><StatusBadge /><small>{r.done}</small></div>
            </button>
          ))}
          <div className="table-foot">
            <span>Menampilkan {shown.length} dari {isFiltering ? filtered.length : fmt(1920)} laporan tuntas · Data simulasi</span>
            <div className="pager" role="navigation" aria-label="Halaman">
              <button disabled={page === 1} onClick={() => setPage((p) => p - 1)} aria-label="Sebelumnya">←</button>
              {pageNums.map((n, i) => n === '…' ? <button key={`e${i}`} disabled>…</button> : <button key={n} className={page === n ? 'on' : ''} onClick={() => setPage(n)}>{n}</button>)}
              <button disabled={page === pages} onClick={() => setPage((p) => p + 1)} aria-label="Berikutnya">→</button>
            </div>
          </div>
        </Reveal>

        {/* Sorotan */}
        <Reveal className="spotlight">
          <div>
            <Photo scene="sidewalk" alt="Trotoar yang sudah diperbaiki" />
            <p className="cap"><CameraIcon size={12} /> Ilustrasi hasil penanganan · Bukan dokumentasi aktual</p>
          </div>
          <div>
            <div className="meta"><StatusBadge /><span>TTS-260918-041 · Bandung</span></div>
            <h3>Trotoar kembali aman. Warga kembali nyaman.</h3>
            <p>Paving yang pecah di Jl. Merdeka diganti dan permukaan jalur diratakan. Unit penanganan jalan mengunggah bukti perbaikan, pelapor mengonfirmasi jalur sudah bisa dilalui dengan aman.</p>
            <div className="timeline">
              {[['18 Sep', 'Dikirim'], ['19 Sep', 'Verifikasi'], ['21 Sep', 'Dikerjakan'], ['25 Sep', 'Ditangani'], ['26 Sep', 'Tuntas']].map(([d, s]) => (
                <div key={s}><b>{d}</b><span>{s}</span></div>
              ))}
            </div>
            <p className="quote" style={{ marginBottom: 14 }}>“Sekarang tidak perlu turun ke jalan saat lewat sini.” — Nadia, pelapor (cerita simulasi)</p>
            <small className="muted small">Selesai dalam 8 hari · 18–26 September 2026 · Data simulasi</small>
          </div>
        </Reveal>

        <Reveal className="cta">
          <div>
            <h2>Perubahan berikutnya bisa dimulai darimu.</h2>
            <p>Temukan masalah di sekitarmu? Sampaikan, lalu ikuti sampai tuntas.</p>
          </div>
          <Link to="/ajukan" className="btn btn-primary">Ajukan pengaduan <ArrowIcon size={14} /></Link>
        </Reveal>
      </div>
    </main>
  )
}
