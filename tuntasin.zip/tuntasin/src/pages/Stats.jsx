// HALAMAN STATISTIK (/statistik)
// Bagian: filter (periode/wilayah/kategori) → 4 kartu angka (KPI) → grafik batang bulanan + donut progres
// → perbandingan wilayah + komposisi kategori → catatan data.
// Fitur: filter benar-benar menghitung ulang semua angka; grafik beranimasi + tooltip saat hover.
import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import Reveal from '../components/Reveal.jsx'
import { Select } from '../components/Common.jsx'
import { CalendarIcon, ArrowIcon, InfoIcon } from '../components/Icons.jsx'
import { MONTHS, MONTHLY_IN, MONTHLY_DONE, REGIONS, CATEGORIES, fmt } from '../data.js'

const TOTAL_IN = REGIONS.reduce((a, r) => a + r.in, 0) // 2.400
const PERIODS = [
  { value: '9', label: 'Jan–Sep 2026' },
  { value: '6', label: 'Jan–Jun 2026' },
  { value: '3', label: 'Jan–Mar 2026' },
]

export default function Stats() {
  // "draft" = pilihan di dropdown; "applied" = yang dipakai setelah klik Terapkan
  const [draft, setDraft] = useState({ period: '9', region: '', cat: '' })
  const [applied, setApplied] = useState(draft)
  const [spin, setSpin] = useState(0) // naik setiap Terapkan → memicu animasi ulang

  const data = useMemo(() => {
    const months = Number(applied.period)
    const catShare = CATEGORIES.find((c) => c.key === applied.cat)?.share ?? 1
    const regionShare = applied.region ? REGIONS.find((r) => r.name === applied.region).in / TOTAL_IN : 1

    const mIn = MONTHLY_IN.slice(0, months).map((v) => Math.round(v * regionShare * catShare))
    const mDone = MONTHLY_DONE.slice(0, months).map((v) => Math.round(v * regionShare * catShare))
    const labels = MONTHS.slice(0, months)

    const regions = REGIONS.map((r) => {
      const periodFactor = MONTHLY_IN.slice(0, months).reduce((a, b) => a + b, 0) / TOTAL_IN
      return {
        name: r.name,
        in: Math.round(r.in * periodFactor * catShare),
        done: Math.round(r.done * periodFactor * catShare),
      }
    }).filter((r) => !applied.region || r.name === applied.region)

    const totalIn = mIn.reduce((a, b) => a + b, 0)
    const totalDone = mDone.reduce((a, b) => a + b, 0)
    const process = totalIn - totalDone
    const verif = Math.round(process * 0.25)
    const follow = process - verif
    const rate = totalIn ? Math.round((totalDone / totalIn) * 100) : 0

    const cats = CATEGORIES.map((c) => ({ key: c.key, n: Math.round(totalIn * (applied.cat ? (c.key === applied.cat ? 1 : 0) : c.share)), share: applied.cat ? (c.key === applied.cat ? 100 : 0) : Math.round(c.share * 100) }))
    return { labels, mIn, mDone, regions, totalIn, totalDone, process, verif, follow, rate, cats }
  }, [applied])

  const apply = () => { setApplied(draft); setSpin((s) => s + 1) }
  const maxBar = 400
  const maxRegion = Math.max(...data.regions.map((r) => r.in), 1)

  // Donut: lingkaran SVG dengan stroke-dasharray
  const R = 80
  const C = 2 * Math.PI * R
  const seg = (n) => (data.totalIn ? (n / data.totalIn) * C : 0)
  const s1 = seg(data.totalDone), s2 = seg(data.follow), s3 = seg(data.verif)

  return (
    <main className="page">
      <div className="container">
        <Reveal className="page-head" style={{ paddingBottom: 0 }}>
          <p className="crumb"><Link to="/">Beranda</Link> / Statistik pengaduan</p>
          <div className="data-head">
            <div>
              <p className="eyebrow">Cerita di balik angka</p>
              <h1 className="h1">Suara warga, dalam data.</h1>
              <p className="lead">Lihat tren laporan, bandingkan wilayah, dan kenali progres penyelesaiannya.</p>
            </div>
            <div className="sim-note">
              <span className="pill">Data simulasi</span>
              <p>Jan–Sep 2026 · 6 daerah ilustratif. Bukan data resmi pemerintah.</p>
            </div>
          </div>
        </Reveal>

        {/* Filter */}
        <Reveal className="card filter-bar">
          <Select id="s-period" label="Periode" value={draft.period} onChange={(v) => setDraft((d) => ({ ...d, period: v }))} options={PERIODS} />
          <Select id="s-region" label="Wilayah" value={draft.region} onChange={(v) => setDraft((d) => ({ ...d, region: v }))} options={REGIONS.map((r) => r.name)} placeholder="Semua wilayah" />
          <Select id="s-cat" label="Kategori" value={draft.cat} onChange={(v) => setDraft((d) => ({ ...d, cat: v }))} options={CATEGORIES.map((c) => c.key)} placeholder="Semua kategori" />
          <button className="btn btn-primary" onClick={apply}>Terapkan</button>
        </Reveal>

        {/* KPI */}
        <div className="kpis" key={`k${spin}`}>
          {[
            { l: 'Pengaduan masuk', v: fmt(data.totalIn), s: `Total ${applied.region ? applied.region : '6 daerah'} simulasi` },
            { l: 'Pengaduan tuntas', v: fmt(data.totalDone), s: 'Sudah selesai ditangani' },
            { l: 'Tingkat penyelesaian', v: `${data.rate}%`, s: 'Tuntas ÷ laporan masuk' },
            { l: 'Masih dalam proses', v: fmt(data.process), s: `Termasuk ${fmt(data.verif)} tahap verifikasi` },
          ].map((k, i) => (
            <Reveal key={k.l} className="card kpi" delay={i * 70}>
              <small>{k.l}</small>
              <strong>{k.v}</strong>
              <span>{k.s}</span>
            </Reveal>
          ))}
        </div>

        {/* Grafik + donut */}
        <div className="dash-grid">
          <Reveal className="card panel">
            <h3>Laporan masuk &amp; tuntas</h3>
            <p className="sub">Jumlah laporan per bulan · {PERIODS.find((p) => p.value === applied.period).label}</p>
            <div className="legend">
              <span><i style={{ background: 'var(--red)' }} />Masuk</span>
              <span><i style={{ background: '#c9cabb' }} />Tuntas</span>
            </div>
            <div className="bars" key={`b${spin}`}>
              <div className="y-axis">{[0, 100, 200, 300, 400].map((t) => <span key={t}>{t}</span>)}</div>
              <div className="plot" style={{ gridTemplateColumns: `repeat(${data.labels.length}, 1fr)` }}>
                {data.labels.map((m, i) => (
                  <div className="bar-group" key={m} tabIndex={0}>
                    <span className="bar-tip">{m}: {data.mIn[i]} masuk · {data.mDone[i]} tuntas</span>
                    <div className="bar in" style={{ height: `${(data.mIn[i] / maxBar) * 100}%`, animationDelay: `${i * 60}ms` }} />
                    <div className="bar done" style={{ height: `${(data.mDone[i] / maxBar) * 100}%`, animationDelay: `${i * 60 + 80}ms` }} />
                    <span className="bar-label">{m}</span>
                  </div>
                ))}
              </div>
            </div>
            <p className="hint" style={{ marginTop: 34 }}>
              {MONTHS[data.labels.length - 1]}: {data.mIn[data.mIn.length - 1]} laporan masuk, {data.mDone[data.mDone.length - 1]} tuntas. Setiap batang tuntas adalah bagian dari laporan masuk pada bulan yang sama.
            </p>
          </Reveal>

          <Reveal className="card panel" delay={100}>
            <h3 style={{ textAlign: 'center' }}>Sudah sampai mana?</h3>
            <div className="donut-box" style={{ marginTop: 18 }}>
              <svg viewBox="0 0 200 200" aria-hidden="true" key={`d${spin}`}>
                <circle cx="100" cy="100" r={R} fill="none" stroke="#efece5" strokeWidth="26" />
                <circle cx="100" cy="100" r={R} fill="none" stroke="var(--red-soft)" strokeWidth="26" strokeDasharray={`${s2 + s1} ${C}`} />
                <circle cx="100" cy="100" r={R} fill="none" stroke="var(--red)" strokeWidth="26" strokeDasharray={`${s1} ${C}`} />
                <circle cx="100" cy="100" r={R} fill="none" stroke="#efece5" strokeWidth="26" strokeDasharray={`${s3} ${C}`} strokeDashoffset={-(s1 + s2)} />
              </svg>
              <div className="donut-center"><b>{data.rate}%</b><small>sudah tuntas</small></div>
            </div>
            <ul className="dl">
              <li><span><i style={{ background: 'var(--red)' }} />Tuntas</span><b>{fmt(data.totalDone)} · {data.rate}%</b></li>
              <li><span><i style={{ background: 'var(--red-soft)' }} />Ditangani</span><b>{fmt(data.follow)} · {data.totalIn ? Math.round((data.follow / data.totalIn) * 100) : 0}%</b></li>
              <li><span><i style={{ background: '#e7e3d8' }} />Verifikasi</span><b>{fmt(data.verif)} · {data.totalIn ? Math.round((data.verif / data.totalIn) * 100) : 0}%</b></li>
            </ul>
          </Reveal>
        </div>

        {/* Bandingkan wilayah + kategori */}
        <div className="dash-grid">
          <Reveal className="card panel">
            <h3>Bandingkan suara daerah</h3>
            <p className="sub">Diurutkan dari jumlah pengaduan masuk terbanyak · {data.regions.length} daerah</p>
            <div className="region-row head"><span /><span>Wilayah</span><span>Pengaduan masuk</span><span style={{ textAlign: 'right' }} /><span style={{ textAlign: 'right' }}>Tuntas</span><span style={{ textAlign: 'right' }}>Rasio</span></div>
            {data.regions.map((r, i) => (
              <div className="region-row" key={`${r.name}${spin}`}>
                <span className="no">{String(i + 1).padStart(2, '0')}</span>
                <span>{r.name}</span>
                <div className="track"><i className={i > 2 ? 'soft' : ''} style={{ width: `${(r.in / maxRegion) * 100}%`, animationDelay: `${i * 80}ms` }} /></div>
                <b>{fmt(r.in)}</b>
                <span className="t">{fmt(r.done)}</span>
                <span className="r">{r.in ? Math.round((r.done / r.in) * 100) : 0}%</span>
              </div>
            ))}
            <div style={{ marginTop: 14 }}>
              <Link className="link" to="/pengaduan-tuntas">Lihat rincian pengaduan tuntas <ArrowIcon size={13} /></Link>
            </div>
          </Reveal>

          <Reveal className="card panel beige" delay={100}>
            <h3>Apa yang dilaporkan?</h3>
            <p className="sub">Komposisi dari {fmt(data.totalIn)} laporan masuk</p>
            {data.cats.map((c, i) => (
              <div className="cat-bar" key={`${c.key}${spin}`}>
                <div className="top"><span>{c.key}</span><b>{fmt(c.n)} · {c.share}%</b></div>
                <div className="track"><i className={i > 0 ? 'soft' : ''} style={{ width: `${c.share}%`, animationDelay: `${i * 100}ms` }} /></div>
              </div>
            ))}
            <p className="hint" style={{ marginTop: 22 }}>Infrastruktur paling banyak dilaporkan. Mulai dari jalan rusak, penerangan, hingga fasilitas umum.</p>
          </Reveal>
        </div>

        <p className="footnote">
          <InfoIcon size={15} />
          <span><b>Tentang data:</b> seluruh angka adalah data simulasi periode 1 Januari–30 September 2026. “Masuk” mencakup semua status, “Tuntas” adalah laporan yang penanganannya telah selesai dan dikonfirmasi. Rasio penyelesaian = pengaduan tuntas ÷ pengaduan masuk × 100%.</span>
        </p>
      </div>
    </main>
  )
}
