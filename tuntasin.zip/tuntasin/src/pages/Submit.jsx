// HALAMAN AJUKAN PENGADUAN (/ajukan)
// Bagian: form 4 langkah (01 Kategori+isi, 02 Lokasi, 03 Bukti, 04 Privasi) + panel tips di kanan
// + penjelasan "apa yang terjadi setelah kirim" (stepper 5 tahap) di bawah.
// Fitur: pilih kategori, hitung karakter, dropdown lokasi bertingkat (provinsi→kota→kecamatan→kelurahan),
// upload file (klik / drag & drop, validasi tipe & ukuran, progress), pilihan anonim, validasi, modal sukses + nomor laporan.
import { useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import Reveal from '../components/Reveal.jsx'
import { Select, Stepper } from '../components/Common.jsx'
import { RoadIcon, LeafIcon, BuildingIcon, PinIcon, UploadIcon, FileIcon, CheckCircleIcon, XIcon, ArrowIcon, EditIcon, ShieldIcon, InfoIcon, CheckIcon, CheckIcon as Tick } from '../components/Icons.jsx'
import { PROVINCES } from '../data.js'

const CATS = [
  { key: 'Infrastruktur', icon: RoadIcon },
  { key: 'Lingkungan', icon: LeafIcon },
  { key: 'Layanan publik', icon: BuildingIcon },
]
const MAX_FILES = 5
const MAX_MB = 10
const OK_TYPES = ['image/jpeg', 'image/png', 'application/pdf']

const sizeLabel = (b) => (b >= 1024 * 1024 ? `${(b / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`)

export default function Submit() {
  const [f, setF] = useState({ cat: 'Infrastruktur', title: '', desc: '', prov: '', city: '', kec: '', kel: '', addr: '', privacy: 'anon', agree: false })
  const [files, setFiles] = useState([])
  const [errors, setErrors] = useState({})
  const [drag, setDrag] = useState(false)
  const [sending, setSending] = useState(false)
  const [ticket, setTicket] = useState(null)
  const inputRef = useRef(null)

  const set = (k, v) => {
    setF((s) => ({ ...s, [k]: v }))
    if (errors[k]) setErrors((e) => ({ ...e, [k]: undefined }))
  }

  // Dropdown bertingkat: pilihan turunan menyesuaikan induknya
  const cities = useMemo(() => Object.keys(PROVINCES[f.prov] || {}), [f.prov])
  const kecs = useMemo(() => Object.keys(PROVINCES[f.prov]?.[f.city] || {}), [f.prov, f.city])
  const kels = useMemo(() => PROVINCES[f.prov]?.[f.city]?.[f.kec] || [], [f.prov, f.city, f.kec])

  const setProv = (v) => { setF((s) => ({ ...s, prov: v, city: '', kec: '', kel: '' })); setErrors((e) => ({ ...e, prov: undefined })) }
  const setCity = (v) => { setF((s) => ({ ...s, city: v, kec: '', kel: '' })); setErrors((e) => ({ ...e, city: undefined })) }
  const setKec = (v) => { setF((s) => ({ ...s, kec: v, kel: '' })); setErrors((e) => ({ ...e, kec: undefined })) }

  // --- Upload file ---
  const addFiles = (list) => {
    const incoming = Array.from(list)
    const next = [...files]
    const msgs = []
    incoming.forEach((file) => {
      if (next.length >= MAX_FILES) return msgs.push(`Maksimal ${MAX_FILES} file.`)
      if (!OK_TYPES.includes(file.type)) return msgs.push(`${file.name}: format harus JPG, PNG, atau PDF.`)
      if (file.size > MAX_MB * 1024 * 1024) return msgs.push(`${file.name}: ukuran lebih dari ${MAX_MB} MB.`)
      const item = { id: crypto.randomUUID?.() || String(Math.random()), name: file.name, size: file.size, progress: 0 }
      next.push(item)
      // Simulasi progres unggah
      const tick = setInterval(() => {
        setFiles((cur) => cur.map((x) => (x.id === item.id ? { ...x, progress: Math.min(100, x.progress + 25) } : x)))
      }, 160)
      setTimeout(() => clearInterval(tick), 800)
    })
    setFiles(next)
    setErrors((e) => ({ ...e, files: msgs.length ? Array.from(new Set(msgs)).join(' ') : undefined }))
  }
  const onDrop = (e) => { e.preventDefault(); setDrag(false); addFiles(e.dataTransfer.files) }

  const validate = () => {
    const e = {}
    if (f.title.trim().length < 8) e.title = 'Judul minimal 8 karakter.'
    if (f.desc.trim().length < 30) e.desc = 'Deskripsi minimal 30 karakter agar mudah dipahami.'
    if (!f.prov) e.prov = 'Pilih provinsi.'
    if (!f.city) e.city = 'Pilih kota / kabupaten.'
    if (!f.kec) e.kec = 'Pilih kecamatan.'
    if (!f.kel) e.kel = 'Pilih kelurahan.'
    if (f.addr.trim().length < 5) e.addr = 'Tulis alamat atau patokan lokasi.'
    if (!f.agree) e.agree = 'Centang pernyataan sebelum mengirim.'
    return e
  }

  const submit = (ev) => {
    ev.preventDefault()
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) {
      const first = Object.keys(e)[0]
      document.getElementById(`f-${first}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      document.getElementById(`f-${first}`)?.focus({ preventScroll: true })
      return
    }
    setSending(true)
    setTimeout(() => {
      const d = new Date()
      const pad = (n) => String(n).padStart(2, '0')
      setTicket(`TTS-${String(d.getFullYear()).slice(2)}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`)
      setSending(false)
    }, 1100)
  }

  const reset = () => {
    setTicket(null)
    setF({ cat: 'Infrastruktur', title: '', desc: '', prov: '', city: '', kec: '', kel: '', addr: '', privacy: 'anon', agree: false })
    setFiles([])
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <main className="page">
      <div className="container">
        <Reveal className="page-head">
          <p className="crumb"><Link to="/">Beranda</Link> / Ajukan pengaduan</p>
          <p className="eyebrow">Mulai dari kepedulianmu</p>
          <h1 className="h1">Ceritakan. Kami bantu teruskan.</h1>
          <p className="lead">Sampaikan dengan jelas, sertakan bukti, dan ikuti prosesnya. Kolom bertanda * wajib diisi.</p>
        </Reveal>

        <div className="submit-grid">
          <Reveal as="form" className="card form-card" onSubmit={submit} noValidate>
            {/* 01 */}
            <section className="fsec">
              <div className="fsec-title"><span>01</span><h2>Apa yang ingin kamu laporkan?</h2></div>
              <p className="label">Kategori pengaduan *</p>
              <div className="cat-grid" role="radiogroup" aria-label="Kategori pengaduan">
                {CATS.map(({ key, icon: Icon }) => (
                  <button type="button" key={key} role="radio" aria-checked={f.cat === key} className={`cat ${f.cat === key ? 'on' : ''}`} onClick={() => set('cat', key)}>
                    <Icon size={16} /> {key}
                  </button>
                ))}
              </div>

              <div className="field">
                <label htmlFor="f-title">Judul pengaduan *</label>
                <input id="f-title" maxLength={100} className={`input ${errors.title ? 'has-error' : ''}`} style={{ paddingRight: 14 }} placeholder="Contoh: Lampu jalan mati di Jalan Melati" value={f.title} onChange={(e) => set('title', e.target.value)} />
                {errors.title ? <p className="field-error">{errors.title}</p> : <p className="hint">Buat judul singkat yang menggambarkan masalah. {f.title.length}/100 karakter.</p>}
              </div>

              <div className="field">
                <label htmlFor="f-desc">Deskripsi kejadian *</label>
                <textarea id="f-desc" maxLength={1000} className={`textarea ${errors.desc ? 'has-error' : ''}`} placeholder="Ceritakan apa yang terjadi, kapan, dan dampaknya." value={f.desc} onChange={(e) => set('desc', e.target.value)} />
                {errors.desc ? <p className="field-error">{errors.desc}</p> : <p className="hint">Jelaskan apa yang terjadi, kapan, dan dampaknya. Hindari data pribadi orang lain. <span className={f.desc.length > 900 ? 'charcount warn' : ''}>{f.desc.length}/1000</span></p>}
              </div>
            </section>

            {/* 02 */}
            <section className="fsec">
              <div className="fsec-title"><span>02</span><h2>Di mana kejadiannya?</h2></div>
              <div className="grid-2">
                <Select id="f-prov" label="Provinsi" required value={f.prov} onChange={setProv} options={Object.keys(PROVINCES)} placeholder="Pilih provinsi" error={errors.prov} />
                <Select id="f-city" label="Kota / Kabupaten" required value={f.city} onChange={setCity} options={cities} placeholder="Pilih kota / kabupaten" disabled={!f.prov} error={errors.city} />
                <Select id="f-kec" label="Kecamatan" required value={f.kec} onChange={setKec} options={kecs} placeholder="Pilih kecamatan" disabled={!f.city} error={errors.kec} />
                <Select id="f-kel" label="Kelurahan" required value={f.kel} onChange={(v) => set('kel', v)} options={kels} placeholder="Pilih kelurahan" disabled={!f.kec} error={errors.kel} />
              </div>
              <div className="field" style={{ marginBottom: 0 }}>
                <label htmlFor="f-addr">Alamat / patokan lokasi *</label>
                <div className="input-wrap">
                  <input id="f-addr" className={`input ${errors.addr ? 'has-error' : ''}`} placeholder="Contoh: Jl. Melati, dekat Taman RW 04" value={f.addr} onChange={(e) => set('addr', e.target.value)} />
                  <span className="input-icon"><PinIcon /></span>
                </div>
                {errors.addr && <p className="field-error">{errors.addr}</p>}
              </div>
            </section>

            {/* 03 */}
            <section className="fsec">
              <div className="fsec-title"><span>03</span><h2>Sertakan bukti pendukung</h2></div>
              <p className="hint" style={{ margin: '-6px 0 14px' }}>Foto atau dokumen yang jelas membantu laporanmu diverifikasi lebih cepat.</p>
              <div
                className={`dropzone ${drag ? 'drag' : ''}`}
                role="button" tabIndex={0}
                onClick={() => inputRef.current?.click()}
                onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), inputRef.current?.click())}
                onDragOver={(e) => { e.preventDefault(); setDrag(true) }}
                onDragLeave={() => setDrag(false)}
                onDrop={onDrop}
              >
                <UploadIcon size={26} />
                <b>Pilih file atau tarik ke sini</b>
                <small>JPG, PNG, PDF · Maksimal {MAX_MB} MB per file · Hingga {MAX_FILES} file</small>
                <input ref={inputRef} id="f-files" type="file" hidden multiple accept=".jpg,.jpeg,.png,.pdf" onChange={(e) => { addFiles(e.target.files); e.target.value = '' }} />
              </div>
              {errors.files && <p className="field-error" style={{ marginTop: 10 }}>{errors.files}</p>}
              {files.length > 0 && (
                <ul className="files">
                  {files.map((x) => (
                    <li className="file" key={x.id}>
                      <FileIcon size={18} />
                      <div className="meta">
                        <b>{x.name}</b>
                        <small>{sizeLabel(x.size)} · {x.progress >= 100 ? 'Berhasil diunggah' : `Mengunggah ${x.progress}%`}</small>
                        {x.progress < 100 && <div className="progress"><i style={{ width: `${x.progress}%` }} /></div>}
                      </div>
                      {x.progress >= 100 && <CheckCircleIcon size={17} className="ok" />}
                      <button type="button" aria-label={`Hapus ${x.name}`} onClick={() => setFiles((c) => c.filter((y) => y.id !== x.id))}><XIcon size={15} /></button>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {/* 04 */}
            <section className="fsec">
              <div className="fsec-title"><span>04</span><h2>Pilih privasimu</h2></div>
              <div className="radio-grid" role="radiogroup" aria-label="Privasi">
                <button type="button" role="radio" aria-checked={f.privacy === 'anon'} className={`radio ${f.privacy === 'anon' ? 'on' : ''}`} onClick={() => set('privacy', 'anon')}>
                  <span className="rt"><span className="dot" /> Anonim</span>
                  <small>Nama disembunyikan dari publik.</small>
                </button>
                <button type="button" role="radio" aria-checked={f.privacy === 'name'} className={`radio ${f.privacy === 'name' ? 'on' : ''}`} onClick={() => set('privacy', 'name')}>
                  <span className="rt"><span className="dot" /> Tampilkan nama</span>
                  <small>Nama tampil bersama laporan.</small>
                </button>
              </div>

              <label className="check">
                <input id="f-agree" type="checkbox" checked={f.agree} onChange={(e) => set('agree', e.target.checked)} />
                <span className="box"><Tick size={11} strokeWidth={3} /></span>
                Saya memastikan laporan ini benar, tidak mengandung fitnah, dan menyetujui ketentuan pengaduan.
              </label>
              {errors.agree && <p className="field-error" style={{ marginTop: 8 }}>{errors.agree}</p>}

              <div className="submit-bar">
                <span className="hint" style={{ margin: 0 }}>Periksa kembali sebelum mengirim.</span>
                <button className="btn btn-primary" disabled={sending}>{sending ? 'Mengirim…' : <>Kirim pengaduan <ArrowIcon size={14} /></>}</button>
              </div>
            </section>
          </Reveal>

          {/* Kolom kanan: tips */}
          <aside className="submit-side">
            <Reveal className="card side-card beige" delay={80}>
              <EditIcon size={20} />
              <h3>Laporan yang baik, awal solusi yang tepat.</h3>
              <ul className="tips">
                <li><b>01</b> Ceritakan satu masalah dalam satu laporan.</li>
                <li><b>02</b> Pilih wilayah sesuai lokasi kejadian.</li>
                <li><b>03</b> Lampirkan bukti yang relevan dan jelas.</li>
                <li><b>04</b> Jangan bagikan NIK, nomor rekening, atau data sensitif.</li>
              </ul>
            </Reveal>
            <Reveal className="card side-card" delay={160}>
              <ShieldIcon size={18} />
              <h3 style={{ fontSize: 15 }}>Kamu tetap terlindungi.</h3>
              <p>Mode anonim menyembunyikan nama dari publik. Tim verifikasi tetap dapat menghubungimu lewat akun.</p>
              <Link className="link" to="/tentang">Tentang privasi <ArrowIcon size={13} /></Link>
            </Reveal>
            <p className="side-note">Tuntasin bukan kanal darurat. Untuk situasi yang mengancam keselamatan, hubungi layanan darurat setempat.</p>
          </aside>
        </div>

        {/* Setelah kirim */}
        <Reveal className="after">
          <p className="eyebrow">Setelah kamu klik kirim</p>
          <div className="after-head">
            <h2 className="h1" style={{ fontSize: 'clamp(26px,3.4vw,34px)', fontWeight: 600 }}>Lalu, apa yang akan terjadi?</h2>
            <p>Simpan nomor laporanmu. Notifikasi perkembangan bisa kamu lihat di akun Tuntasin.</p>
          </div>
          <Stepper active={0} />
          <div className="callout"><InfoIcon size={16} /> Waktu penanganan berbeda untuk setiap masalah. Jika bukti belum lengkap, tim akan meminta informasi tambahan melalui akunmu.</div>
        </Reveal>
      </div>

      {/* Modal sukses */}
      {ticket && (
        <div className="overlay" role="dialog" aria-modal="true" aria-labelledby="ok-title" onClick={(e) => e.target === e.currentTarget && reset()}>
          <div className="modal">
            <div className="big-check"><CheckIcon size={30} strokeWidth={2.4} /></div>
            <h3 id="ok-title">Pengaduan terkirim!</h3>
            <p>Terima kasih sudah bersuara. Simpan nomor laporan ini untuk memantau prosesnya.</p>
            <div className="ticket">{ticket}</div>
            <div className="row" style={{ gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link to="/cari-laporan" className="btn btn-ghost">Lihat arsip</Link>
              <button className="btn btn-primary" onClick={reset}>Buat laporan baru</button>
            </div>
          </div>
        </div>
      )}
    </main>
  )
}
