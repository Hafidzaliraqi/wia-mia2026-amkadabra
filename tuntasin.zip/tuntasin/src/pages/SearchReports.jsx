// HALAMAN CARI LAPORAN (/cari-laporan?q=kata)
// Bagian: hero pink + kolom pencarian besar → sidebar "Persempit hasil" (filter) → daftar hasil (kartu)
// → ajakan membuat laporan baru.
// Fitur: pencarian kata kunci (judul/lokasi/nomor/isi) dengan sorotan kata, kata kunci tersimpan di URL,
// filter wilayah/kategori, urutan, chip filter aktif yang bisa dihapus, pagination 3 hasil per halaman.
import { useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import Reveal from '../components/Reveal.jsx'
import Photo from '../components/Photo.jsx'
import { Select, StatusBadge } from '../components/Common.jsx'
import { SearchIcon, XIcon, InfoIcon, PinIcon, ArrowIcon, ShieldIcon, LockIcon, CheckCircleIcon, FilterIcon, CalendarIcon } from '../components/Icons.jsx'
import { REPORTS, REGIONS, CATEGORIES } from '../data.js'

const PER_PAGE = 3
const SORTS = [
  { value: 'new', label: 'Terbaru selesai' },
  { value: 'old', label: 'Terlama selesai' },
  { value: 'fast', label: 'Tercepat ditangani' },
]

// Bungkus kata kunci dengan <mark> agar tersorot
function Highlight({ text, term }) {
  if (!term) return text
  const safe = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  return text.split(new RegExp(`(${safe})`, 'ig')).map((part, i) =>
    part.toLowerCase() === term.toLowerCase() ? <mark className="hl" key={i}>{part}</mark> : part
  )
}

export default function SearchReports() {
  const [params, setParams] = useSearchParams()
  const term = params.get('q') ?? 'trotoar'
  const [input, setInput] = useState(term)
  const [draft, setDraft] = useState({ region: '', cat: '' })
  const [applied, setApplied] = useState({ region: '', cat: '' })
  const [sort, setSort] = useState('new')
  const [page, setPage] = useState(1)

  const results = useMemo(() => {
    const k = term.trim().toLowerCase()
    const list = REPORTS.filter((r) =>
      (!applied.region || r.region === applied.region) &&
      (!applied.cat || r.cat === applied.cat) &&
      (!k || [r.title, r.id, r.region, r.result, r.cat].some((s) => s.toLowerCase().includes(k)))
    )
    // Urutkan: indeks asli di REPORTS ≈ urutan terbaru → terlama
    const idx = (r) => REPORTS.indexOf(r)
    if (sort === 'old') list.sort((a, b) => idx(b) - idx(a))
    else if (sort === 'fast') list.sort((a, b) => a.days - b.days)
    else list.sort((a, b) => idx(a) - idx(b))
    return list
  }, [term, applied, sort])

  const pages = Math.max(1, Math.ceil(results.length / PER_PAGE))
  const current = Math.min(page, pages)
  const shown = results.slice((current - 1) * PER_PAGE, current * PER_PAGE)
  const from = results.length ? (current - 1) * PER_PAGE + 1 : 0

  const doSearch = (e) => {
    e?.preventDefault()
    const v = input.trim()
    setParams(v ? { q: v } : {})
    setPage(1)
  }
  const clearTerm = () => { setInput(''); setParams({}); setPage(1) }
  const applyFilters = () => { setApplied(draft); setPage(1) }
  const reset = () => { setDraft({ region: '', cat: '' }); setApplied({ region: '', cat: '' }); setPage(1) }

  return (
    <main className="page" style={{ paddingBottom: 0 }}>
      {/* Hero pencarian */}
      <section className="search-hero">
        <div className="container">
          <Reveal>
            <p className="crumb"><Link to="/">Beranda</Link> / Cari laporan</p>
            <div className="search-hero-grid">
              <div style={{ maxWidth: 680 }}>
                <p className="eyebrow">Arsip perubahan warga</p>
                <h1 className="h1">Cari masalahnya. Lihat penyelesaiannya.</h1>
                <p className="lead">Telusuri laporan warga yang sudah tuntas. Temukan jejak penanganan, hasil perbaikan, dan cerita dari lingkungan kita.</p>
              </div>
              <div className="stat">
                <strong>1.920</strong>
                <p>laporan tuntas dalam arsip</p>
                <span className="pill">Data simulasi</span>
                <small>Jan–Sep 2026 · 6 daerah<br />Bukan data resmi pemerintah.</small>
              </div>
            </div>

            <form className="big-search" onSubmit={doSearch} role="search">
              <SearchIcon size={20} />
              <input aria-label="Cari laporan" placeholder="Cari kata kunci, lokasi, atau nomor laporan" value={input} onChange={(e) => setInput(e.target.value)} />
              {input && <button type="button" className="clear" onClick={clearTerm} aria-label="Hapus pencarian"><XIcon size={16} /></button>}
              <button className="btn btn-primary">Cari laporan <SearchIcon size={15} /></button>
            </form>
            <p className="search-tip"><InfoIcon size={14} /> Cari dengan kata kunci, lokasi, atau nomor laporan. Arsip ini menampilkan pengaduan berstatus tuntas.</p>
          </Reveal>
        </div>
      </section>

      <div className="container">
        <div className="search-layout">
          {/* Sidebar filter */}
          <aside className="filter-side">
            <div className="top"><h3>Persempit hasil</h3><button className="reset" onClick={reset}>Reset filter</button></div>
            <div className="card filter-card">
              <div className="filter-fields">
                <Select id="c-region" label="Wilayah" value={draft.region} onChange={(v) => setDraft((d) => ({ ...d, region: v }))} options={REGIONS.map((r) => r.name)} placeholder="Semua wilayah" />
                <Select id="c-cat" label="Kategori" value={draft.cat} onChange={(v) => setDraft((d) => ({ ...d, cat: v }))} options={CATEGORIES.map((c) => c.key)} placeholder="Semua kategori" />
                <div className="field">
                  <label htmlFor="c-period">Periode selesai</label>
                  <div className="input-wrap"><input id="c-period" className="input" value="Jan–Sep 2026" readOnly /><span className="input-icon"><CalendarIcon size={15} /></span></div>
                </div>
                <div className="field">
                  <label>Status laporan</label>
                  <div className="locked"><CheckCircleIcon size={15} /> Tuntas <LockIcon size={13} /></div>
                  <p className="hint">Hanya laporan yang sudah selesai dan dikonfirmasi.</p>
                </div>
              </div>
              <button className="btn btn-primary btn-block" onClick={applyFilters} style={{ padding: 12, fontSize: 13 }}>Terapkan filter <FilterIcon size={14} /></button>
            </div>

            <div className="privacy-card">
              <ShieldIcon size={18} />
              <h4>Terbuka prosesnya. Terjaga identitasnya.</h4>
              <p>Identitas pelapor anonim dan data pribadi tidak ditampilkan dalam arsip publik.</p>
              <Link className="link" to="/tentang">Tentang privasi <ArrowIcon size={12} /></Link>
            </div>
            <Link className="link" to="/statistik">Lihat ringkasan daerah <ArrowIcon size={13} /></Link>
          </aside>

          {/* Hasil */}
          <section aria-live="polite">
            <div className="results-head">
              <div>
                <h2>{results.length} hasil{term && <> untuk “{term}”</>}</h2>
                <p className="sub">{applied.region || 'Semua wilayah'} · Jan–Sep 2026 · Data simulasi</p>
              </div>
              <label className="sort"><select className="sort-select" value={sort} onChange={(e) => { setSort(e.target.value); setPage(1) }} aria-label="Urutkan hasil">
                {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label} ↓</option>)}
              </select></label>
            </div>

            <div className="chips">
              {term && <span className="chip">Kata kunci: {term} <button onClick={clearTerm} aria-label="Hapus kata kunci"><XIcon size={11} /></button></span>}
              {applied.region && <span className="chip">Wilayah: {applied.region} <button onClick={() => { setApplied((a) => ({ ...a, region: '' })); setDraft((d) => ({ ...d, region: '' })) }} aria-label="Hapus wilayah"><XIcon size={11} /></button></span>}
              {applied.cat && <span className="chip">Kategori: {applied.cat} <button onClick={() => { setApplied((a) => ({ ...a, cat: '' })); setDraft((d) => ({ ...d, cat: '' })) }} aria-label="Hapus kategori"><XIcon size={11} /></button></span>}
              <span className="chip green"><CheckCircleIcon size={12} /> Tuntas</span>
            </div>

            {shown.length === 0 && (
              <div className="card empty">
                <p><b style={{ color: 'var(--ink)' }}>Belum ada laporan yang cocok.</b></p>
                <p style={{ marginTop: 6 }}>Coba kata kunci lain seperti “lampu”, “sampah”, atau nomor laporan TTS-…</p>
              </div>
            )}

            {shown.map((r, i) => (
              <Reveal as="article" className="card result" key={r.id} delay={i * 80}>
                <div>
                  <div className="top"><StatusBadge /><span>{r.id}</span><span>{r.cat}</span></div>
                  <h3><Highlight text={r.title} term={term.trim()} /></h3>
                  <div className="meta">
                    <span><PinIcon size={13} />{r.region}</span>
                    <span>Selesai {r.done}</span>
                  </div>
                  <p className="desc"><Highlight text={r.result} term={term.trim()} /></p>
                </div>
                <div className="thumb">
                  <Photo scene={r.scene} alt={`Ilustrasi: ${r.title}`} />
                  <small>Foto ilustrasi, bukan aktual</small>
                </div>
                <div className="foot">
                  <span>Dikirim {r.sent} · Tuntas {r.done} · {r.days} hari</span>
                  <Link className="link" to="/pengaduan-tuntas">Lihat penyelesaian <ArrowIcon size={13} /></Link>
                </div>
              </Reveal>
            ))}

            {results.length > 0 && (
              <div className="table-foot" style={{ border: 0, padding: '8px 0' }}>
                <span>Menampilkan {from}–{from + shown.length - 1} dari {results.length} hasil · Data simulasi</span>
                <div className="pager" role="navigation" aria-label="Halaman">
                  <button disabled={current === 1} onClick={() => setPage(current - 1)} aria-label="Sebelumnya">←</button>
                  {Array.from({ length: pages }, (_, i) => i + 1).map((n) => <button key={n} className={n === current ? 'on' : ''} onClick={() => setPage(n)}>{n}</button>)}
                  <button disabled={current === pages} onClick={() => setPage(current + 1)} aria-label="Berikutnya">→</button>
                </div>
              </div>
            )}

            <p className="disclaimer"><InfoIcon size={14} /> Seluruh laporan, tanggal, hasil penanganan, dan foto pada halaman ini merupakan ilustrasi desain. Bukan data resmi pemerintah atau bukti aktual.</p>
          </section>
        </div>
      </div>

      <section className="bottom-cta">
        <div className="container cta">
          <div>
            <h2>Belum menemukan masalah yang kamu cari?</h2>
            <p>Ada masalah di sekitarmu? Sampaikan laporan baru, lalu ikuti sampai tuntas.</p>
          </div>
          <Link to="/ajukan" className="btn btn-primary">Ajukan pengaduan <ArrowIcon size={14} /></Link>
        </div>
      </section>
    </main>
  )
}
