// HALAMAN REGISTRASI (/registrasi)
// Bagian: panel motivasi kiri + form buat akun kanan.
// Fitur: validasi tiap kolom, indikator kekuatan sandi, konfirmasi sandi, persetujuan syarat, layar sukses.
import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Photo from '../components/Photo.jsx'
import Reveal from '../components/Reveal.jsx'
import { StatusBadge } from '../components/Common.jsx'
import { MailIcon, EyeIcon, EyeOffIcon, ArrowIcon, CheckIcon, MailCheckIcon, CheckCircleIcon } from '../components/Icons.jsx'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

// Hitung skor kekuatan sandi 0–4
function scorePassword(p) {
  let s = 0
  if (p.length >= 8) s++
  if (/[a-z]/.test(p) && /[A-Z]/.test(p)) s++
  if (/\d/.test(p)) s++
  if (/[^A-Za-z0-9]/.test(p) || p.length >= 12) s++
  return s
}
const LABELS = ['', 'Lemah', 'Cukup', 'Baik', 'Kuat']

function PasswordField({ id, label, value, onChange, placeholder, error, hint, children }) {
  const [show, setShow] = useState(false)
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <div className="input-wrap">
        <input id={id} type={show ? 'text' : 'password'} autoComplete="new-password" className={`input ${error ? 'has-error' : ''}`} placeholder={placeholder} value={value} onChange={(e) => onChange(e.target.value)} aria-invalid={!!error} />
        <button type="button" className="input-icon" onClick={() => setShow((s) => !s)} aria-label={show ? 'Sembunyikan kata sandi' : 'Lihat kata sandi'}>
          {show ? <EyeIcon /> : <EyeOffIcon />}
        </button>
      </div>
      {children}
      {error ? <p className="field-error">{error}</p> : hint && <p className="hint">{hint}</p>}
    </div>
  )
}

export default function Register() {
  const navigate = useNavigate()
  const [f, setF] = useState({ name: '', email: '', wa: '', pw: '', pw2: '', agree: false })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)

  const set = (k, v) => {
    setF((s) => ({ ...s, [k]: v }))
    if (errors[k]) setErrors((e) => ({ ...e, [k]: undefined }))
  }
  const score = useMemo(() => scorePassword(f.pw), [f.pw])

  const validate = () => {
    const e = {}
    if (f.name.trim().length < 3) e.name = 'Nama lengkap minimal 3 karakter.'
    if (!EMAIL_RE.test(f.email)) e.email = 'Masukkan email aktif yang valid.'
    if (f.wa && !/^(\+62|62|0)8\d{7,11}$/.test(f.wa.replace(/[\s-]/g, ''))) e.wa = 'Nomor WhatsApp belum benar (contoh: 08123456789).'
    if (f.pw.length < 8 || !/[A-Za-z]/.test(f.pw) || !/\d/.test(f.pw)) e.pw = 'Minimal 8 karakter, kombinasi huruf dan angka.'
    if (f.pw2 !== f.pw || !f.pw2) e.pw2 = 'Konfirmasi kata sandi belum sama.'
    if (!f.agree) e.agree = 'Kamu perlu menyetujui syarat dan kebijakan privasi.'
    return e
  }

  const submit = (ev) => {
    ev.preventDefault()
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) {
      // fokuskan ke kolom pertama yang salah
      const first = Object.keys(e)[0]
      document.getElementById(`reg-${first}`)?.focus()
      return
    }
    setLoading(true)
    setTimeout(() => { setLoading(false); setDone(true) }, 1000) // simulasi API
  }

  return (
    <main className="page auth">
      <div className="container auth-grid">
        <Reveal as="aside" className="auth-aside">
          <p className="eyebrow">Dari suara, jadi perubahan</p>
          <h2>Perubahan baik dimulai darimu.</h2>
          <Photo scene="street" alt="Dua warga berjalan di gang yang sudah rapi" />
          <blockquote>“Trotoar yang dulu rusak sekarang aman. Senang rasanya laporan kami benar-benar ditindaklanjuti.”</blockquote>
          <div className="by">
            <div>
              <b>Nadia • Warga Bandung</b>
              <small>Cerita ilustratif · Data simulasi</small>
            </div>
            <StatusBadge />
          </div>
        </Reveal>

        <Reveal className="auth-form" delay={100}>
          {done ? (
            <div style={{ paddingTop: 24 }}>
              <div className="big-check" style={{ width: 60, height: 60, borderRadius: '50%', background: 'var(--green-bg)', color: 'var(--green)', display: 'grid', placeItems: 'center', marginBottom: 20 }}>
                <MailCheckIcon size={28} />
              </div>
              <p className="eyebrow">Akun berhasil dibuat</p>
              <h1>Cek kotak masukmu.</h1>
              <p className="lead">Kami mengirim tautan verifikasi ke <b style={{ color: 'var(--ink)' }}>{f.email}</b>. Verifikasi email sebelum mengirim pengaduan.</p>
              <div className="row gap">
                <button className="btn btn-primary" onClick={() => navigate('/login')}>Ke halaman login <ArrowIcon size={14} /></button>
              </div>
            </div>
          ) : (
            <>
              <p className="eyebrow">Jadi bagian dari perubahan</p>
              <h1>Buat akun. Mulai bersuara.</h1>
              <p className="lead" style={{ marginBottom: 26 }}>Satu akun untuk menyampaikan laporan dan mengikuti setiap langkah penyelesaiannya.</p>

              <form onSubmit={submit} noValidate>
                <div className="field">
                  <label htmlFor="reg-name">Nama lengkap *</label>
                  <input id="reg-name" className={`input ${errors.name ? 'has-error' : ''}`} style={{ paddingRight: 14 }} placeholder="Sesuai identitasmu" autoComplete="name" value={f.name} onChange={(e) => set('name', e.target.value)} />
                  {errors.name && <p className="field-error">{errors.name}</p>}
                </div>

                <div className="field">
                  <label htmlFor="reg-email">Alamat email *</label>
                  <div className="input-wrap">
                    <input id="reg-email" type="email" autoComplete="email" className={`input ${errors.email ? 'has-error' : ''}`} placeholder="nama@email.com" value={f.email} onChange={(e) => set('email', e.target.value)} />
                    <span className="input-icon"><MailIcon /></span>
                  </div>
                  {errors.email ? <p className="field-error">{errors.email}</p> : <p className="hint">Gunakan email aktif untuk verifikasi dan kabar laporan.</p>}
                </div>

                <div className="field">
                  <label htmlFor="reg-wa">Nomor WhatsApp (opsional)</label>
                  <input id="reg-wa" inputMode="tel" className={`input ${errors.wa ? 'has-error' : ''}`} style={{ paddingRight: 14 }} placeholder="08xxxxxxxxxx" value={f.wa} onChange={(e) => set('wa', e.target.value)} />
                  {errors.wa && <p className="field-error">{errors.wa}</p>}
                </div>

                <PasswordField id="reg-pw" label="Kata sandi *" value={f.pw} onChange={(v) => set('pw', v)} placeholder="Buat kata sandi yang kuat" error={errors.pw} hint="Minimal 8 karakter, kombinasi huruf dan angka.">
                  {f.pw && (
                    <div className="strength" aria-live="polite">
                      {[1, 2, 3, 4].map((i) => <i key={i} className={i <= score ? `on-${score}` : ''} />)}
                      <span>{LABELS[score]}</span>
                    </div>
                  )}
                </PasswordField>

                <PasswordField id="reg-pw2" label="Konfirmasi kata sandi *" value={f.pw2} onChange={(v) => set('pw2', v)} placeholder="Ulangi kata sandi" error={errors.pw2} />

                <label className="check" style={{ marginBottom: errors.agree ? 6 : 20 }}>
                  <input id="reg-agree" type="checkbox" checked={f.agree} onChange={(e) => set('agree', e.target.checked)} />
                  <span className="box"><CheckIcon size={11} strokeWidth={3} /></span>
                  Saya menyetujui Syarat Penggunaan dan Kebijakan Privasi Tuntasin.
                </label>
                {errors.agree && <p className="field-error" style={{ marginBottom: 16 }}>{errors.agree}</p>}

                <button className="btn btn-primary btn-block" disabled={loading}>
                  {loading ? 'Membuat akun…' : <>Buat akun <ArrowIcon size={14} /></>}
                </button>
              </form>

              <p className="auth-foot">Sudah punya akun? <Link className="link" to="/login">Login di sini <ArrowIcon size={13} /></Link></p>
              <p className="note" style={{ marginTop: 22 }}>
                <MailCheckIcon size={16} /> Setelah registrasi, cek kotak masuk untuk memverifikasi email sebelum mengirim pengaduan.
              </p>
            </>
          )}
        </Reveal>
      </div>
    </main>
  )
}
