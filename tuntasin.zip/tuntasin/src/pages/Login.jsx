// HALAMAN LOGIN (/login)
// Bagian: panel testimoni kiri (pink) + form masuk kanan.
// Fitur: validasi email & kata sandi, tombol lihat/sembunyikan sandi, "Ingat saya", loading saat submit.
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Photo from '../components/Photo.jsx'
import Reveal from '../components/Reveal.jsx'
import { StatusBadge, Toast } from '../components/Common.jsx'
import { MailIcon, EyeIcon, EyeOffIcon, ArrowIcon, LockIcon, CheckIcon } from '../components/Icons.jsx'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export default function Login() {
  const navigate = useNavigate()
  const [form, setForm] = useState({ email: '', password: '', remember: false })
  const [show, setShow] = useState(false)
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState('')

  const set = (k, v) => {
    setForm((f) => ({ ...f, [k]: v }))
    if (errors[k]) setErrors((e) => ({ ...e, [k]: undefined })) // hapus error saat mengetik
  }

  const validate = () => {
    const e = {}
    if (!form.email.trim()) e.email = 'Email wajib diisi.'
    else if (!EMAIL_RE.test(form.email)) e.email = 'Format email belum benar.'
    if (!form.password) e.password = 'Kata sandi wajib diisi.'
    else if (form.password.length < 8) e.password = 'Kata sandi minimal 8 karakter.'
    return e
  }

  const submit = (ev) => {
    ev.preventDefault()
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) return
    setLoading(true)
    // Simulasi panggilan API — ganti dengan request login sungguhan
    setTimeout(() => {
      setLoading(false)
      setToast('Berhasil masuk. Mengalihkan…')
      setTimeout(() => navigate('/ajukan'), 900)
    }, 900)
  }

  return (
    <main className="page auth">
      <div className="container auth-grid">
        {/* Panel kiri: testimoni */}
        <Reveal as="aside" className="auth-aside">
          <p className="eyebrow">Dari suara, jadi perubahan</p>
          <h2>Satu laporan. Banyak yang merasakan.</h2>
          <Photo scene="street" alt="Dua warga berjalan di gang yang sudah rapi" />
          <blockquote>“Trotoar yang dulu rusak sekarang aman. Senang rasanya laporan kami benar-benar ditindaklanjuti.”</blockquote>
          <div className="by">
            <div>
              <b>Nadia • Warga Bandung</b>
              <small>Cerita ilustratif · Data simulasi</small>
            </div>
            <StatusBadge />
          </div>
        </Reveal>

        {/* Panel kanan: form */}
        <Reveal className="auth-form" delay={100}>
          <p className="eyebrow">Selamat datang kembali</p>
          <h1>Lanjutkan perubahanmu.</h1>
          <p className="lead">Masuk untuk membuat pengaduan, melihat tanggapan, dan memantau laporanmu sampai tuntas.</p>

          <form onSubmit={submit} noValidate>
            <div className="field">
              <label htmlFor="email">Alamat email</label>
              <div className="input-wrap">
                <input id="email" type="email" autoComplete="email" className={`input ${errors.email ? 'has-error' : ''}`} placeholder="nama@email.com" value={form.email} onChange={(e) => set('email', e.target.value)} aria-invalid={!!errors.email} />
                <span className="input-icon"><MailIcon /></span>
              </div>
              {errors.email && <p className="field-error">{errors.email}</p>}
            </div>

            <div className="field">
              <label htmlFor="password">Kata sandi</label>
              <div className="input-wrap">
                <input id="password" type={show ? 'text' : 'password'} autoComplete="current-password" className={`input ${errors.password ? 'has-error' : ''}`} placeholder="Masukkan kata sandi" value={form.password} onChange={(e) => set('password', e.target.value)} aria-invalid={!!errors.password} />
                <button type="button" className="input-icon" onClick={() => setShow((s) => !s)} aria-label={show ? 'Sembunyikan kata sandi' : 'Lihat kata sandi'}>
                  {show ? <EyeIcon /> : <EyeOffIcon />}
                </button>
              </div>
              {errors.password && <p className="field-error">{errors.password}</p>}
            </div>

            <div className="row-between">
              <label className="check">
                <input type="checkbox" checked={form.remember} onChange={(e) => set('remember', e.target.checked)} />
                <span className="box"><CheckIcon size={11} strokeWidth={3} /></span>
                Ingat saya
              </label>
              <button type="button" className="link" onClick={() => setToast('Tautan reset kata sandi akan dikirim ke emailmu (simulasi).')}>
                Lupa kata sandi? <ArrowIcon size={13} />
              </button>
            </div>

            <button className="btn btn-primary btn-block" disabled={loading}>
              {loading ? 'Memproses…' : <>Login <ArrowIcon size={14} /></>}
            </button>
          </form>

          <p className="auth-foot">
            Belum punya akun? <Link className="link" to="/registrasi">Registrasi sekarang <ArrowIcon size={13} /></Link>
          </p>

          <div className="divider" />
          <p className="secure"><LockIcon size={17} /> Akun aman, suara tetap terlindungi.</p>
          <p className="note" style={{ margin: '14px 0 18px' }}>
            Kami tidak menampilkan email atau kata sandi di pengaduan publik. Pilihan identitas dapat kamu atur saat melapor.
          </p>
          <button className="link" onClick={() => setToast('Pusat bantuan akan segera tersedia.')}>
            Butuh bantuan login? <ArrowIcon size={13} />
          </button>
        </Reveal>
      </div>
      <Toast message={toast} onClose={() => setToast('')} />
    </main>
  )
}
