// APP: daftar rute (URL -> halaman) + layout bersama (Navbar & Footer di semua halaman).
import { useEffect } from 'react'
import { Routes, Route, Navigate, useLocation, Link } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Footer from './components/Footer.jsx'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import Submit from './pages/Submit.jsx'
import Stats from './pages/Stats.jsx'
import Resolved from './pages/Resolved.jsx'
import SearchReports from './pages/SearchReports.jsx'

// Scroll otomatis ke atas setiap pindah halaman (terasa lebih halus)
function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' })
  }, [pathname])
  return null
}

// Halaman sementara untuk menu yang belum didesain (Tentang, Rating)
function Placeholder({ title }) {
  return (
    <main className="page">
      <div className="container narrow-page">
        <p className="eyebrow">Segera hadir</p>
        <h1 className="h1">{title}</h1>
        <p className="lead">Halaman ini belum tersedia di desain. Sementara, kamu bisa mulai dari sini:</p>
        <div className="row gap">
          <Link className="btn btn-primary" to="/ajukan">Ajukan pengaduan</Link>
          <Link className="btn btn-ghost" to="/pengaduan-tuntas">Lihat pengaduan tuntas</Link>
        </div>
      </div>
    </main>
  )
}

export default function App() {
  return (
    <div className="app">
      <ScrollToTop />
      <Navbar />
      <Routes>
        <Route path="/" element={<Navigate to="/pengaduan-tuntas" replace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/registrasi" element={<Register />} />
        <Route path="/ajukan" element={<Submit />} />
        <Route path="/statistik" element={<Stats />} />
        <Route path="/pengaduan-tuntas" element={<Resolved />} />
        <Route path="/cari-laporan" element={<SearchReports />} />
        <Route path="/tentang" element={<Placeholder title="Tentang Tuntasin" />} />
        <Route path="/rating" element={<Placeholder title="Rating pengalaman warga" />} />
        <Route path="*" element={<Placeholder title="Halaman tidak ditemukan" />} />
      </Routes>
      <Footer />
    </div>
  )
}
