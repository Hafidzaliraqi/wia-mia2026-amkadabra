// DATA SIMULASI: semua angka & laporan di sini hanya ilustrasi desain (bukan data resmi).
// Nanti bisa diganti dengan data dari API/backend.

export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep']
export const MONTHLY_IN = [180, 210, 240, 260, 280, 290, 300, 320, 320] // total 2.400
export const MONTHLY_DONE = [120, 150, 185, 210, 225, 235, 250, 265, 280] // total 1.920

export const REGIONS = [
  { name: 'Bandung', in: 680, done: 544 },
  { name: 'Surabaya', in: 540, done: 432 },
  { name: 'Semarang', in: 420, done: 336 },
  { name: 'Yogyakarta', in: 320, done: 256 },
  { name: 'Malang', in: 260, done: 208 },
  { name: 'Denpasar', in: 180, done: 144 },
]

export const CATEGORIES = [
  { key: 'Infrastruktur', share: 0.45 },
  { key: 'Lingkungan', share: 0.3 },
  { key: 'Layanan publik', share: 0.25 },
]

// Laporan yang sudah tuntas (dipakai halaman "Pengaduan Tuntas" & "Cari Laporan")
export const REPORTS = [
  { id: 'TTS-260918-041', title: 'Trotoar rusak di Jl. Merdeka', region: 'Bandung', cat: 'Infrastruktur', days: 8, sent: '18 Sep', done: '26 Sep 2026', doneShort: '26 Sep 2026', result: 'Paving diganti dan jalur pejalan kaki kembali aman.', scene: 'sidewalk' },
  { id: 'TTS-260920-032', title: 'Sampah menumpuk di Pasar Pucang', region: 'Surabaya', cat: 'Lingkungan', days: 5, sent: '20 Sep', done: '25 Sep 2026', result: 'Sampah diangkut; jadwal pengambilan rutin ditambahkan.', scene: 'street' },
  { id: 'TTS-260915-018', title: 'Lampu jalan padam di Jl. Sukun', region: 'Semarang', cat: 'Infrastruktur', days: 9, sent: '15 Sep', done: '24 Sep 2026', result: 'Empat unit lampu diganti dan diuji pada malam hari.', scene: 'street' },
  { id: 'TTS-260917-027', title: 'Antrean layanan kelurahan tidak tertib', region: 'Yogyakarta', cat: 'Layanan publik', days: 7, sent: '17 Sep', done: '24 Sep 2026', result: 'Nomor antrean dan petunjuk layanan sudah tersedia.', scene: 'street' },
  { id: 'TTS-260916-011', title: 'Saluran air tersumbat di Jl. Ijen', region: 'Malang', cat: 'Lingkungan', days: 7, sent: '16 Sep', done: '23 Sep 2026', result: 'Sedimen dibersihkan, aliran air kembali lancar.', scene: 'street' },
  { id: 'TTS-260914-009', title: 'Rambu penyeberangan rusak', region: 'Denpasar', cat: 'Infrastruktur', days: 8, sent: '14 Sep', done: '22 Sep 2026', result: 'Rambu baru terpasang di dekat area sekolah.', scene: 'street' },
  { id: 'TTS-260910-024', title: 'Trotoar berlubang di Jl. Pemuda', region: 'Semarang', cat: 'Infrastruktur', days: 10, sent: '10 Sep', done: '20 Sep 2026', result: 'Bagian trotoar yang berlubang ditutup dan paving ditata ulang. Akses pejalan kaki kembali dapat digunakan.', scene: 'sidewalk' },
  { id: 'TTS-260903-015', title: 'Akses trotoar terhalang di Jl. Diponegoro', region: 'Yogyakarta', cat: 'Infrastruktur', days: 11, sent: '3 Sep', done: '14 Sep 2026', result: 'Penghalang dipindahkan dan akses trotoar ditata kembali. Warga dapat melintas tanpa harus turun ke jalan.', scene: 'street' },
  { id: 'TTS-260901-008', title: 'Trotoar licin dan berlumut di Jl. Basuki Rahmat', region: 'Surabaya', cat: 'Infrastruktur', days: 9, sent: '1 Sep', done: '10 Sep 2026', result: 'Permukaan dibersihkan dan diberi lapisan anti-selip.', scene: 'sidewalk' },
  { id: 'TTS-260828-044', title: 'Trotoar tidak ramah disabilitas di Jl. Braga', region: 'Bandung', cat: 'Infrastruktur', days: 12, sent: '28 Agu', done: '9 Sep 2026', result: 'Jalur ubin pemandu dan ram landai dipasang.', scene: 'sidewalk' },
  { id: 'TTS-260825-031', title: 'Tempat sampah umum penuh di Taman Kota', region: 'Malang', cat: 'Lingkungan', days: 6, sent: '25 Agu', done: '31 Agu 2026', result: 'Tempat sampah ditambah dan dijadwalkan dikosongkan harian.', scene: 'street' },
  { id: 'TTS-260822-019', title: 'Loket pelayanan tidak ada petunjuk', region: 'Denpasar', cat: 'Layanan publik', days: 5, sent: '22 Agu', done: '27 Agu 2026', result: 'Papan petunjuk loket dipasang dan petugas informasi ditempatkan.', scene: 'street' },
  { id: 'TTS-260819-012', title: 'Genangan air di Jl. Pandanaran', region: 'Semarang', cat: 'Lingkungan', days: 8, sent: '19 Agu', done: '27 Agu 2026', result: 'Drainase diperbaiki sehingga genangan surut lebih cepat.', scene: 'street' },
]

export const PROVINCES = {
  'Jawa Barat': {
    'Kota Bandung': { Coblong: ['Lebak Gede', 'Dago', 'Sadang Serang'], 'Bandung Wetan': ['Citarum', 'Tamansari'] },
    'Kota Bogor': { 'Bogor Tengah': ['Babakan Pasar', 'Cibogor'], 'Bogor Barat': ['Menteng', 'Gunung Batu'] },
  },
  'Jawa Tengah': {
    'Kota Semarang': { 'Semarang Tengah': ['Pekunden', 'Miroto'], Candisari: ['Jomblang', 'Candi'] },
    'Kota Surakarta': { Laweyan: ['Pajang', 'Sondakan'], Banjarsari: ['Manahan', 'Punggawan'] },
  },
  'Jawa Timur': {
    'Kota Surabaya': { Gubeng: ['Airlangga', 'Kertajaya'], Tegalsari: ['Keputran', 'Dr. Soetomo'] },
    'Kota Malang': { Klojen: ['Oro-oro Dowo', 'Kauman'], Lowokwaru: ['Dinoyo', 'Ketawanggede'] },
  },
  'DI Yogyakarta': {
    'Kota Yogyakarta': { Gondokusuman: ['Kotabaru', 'Terban'], Jetis: ['Cokrodiningratan', 'Bumijo'] },
  },
  Bali: {
    'Kota Denpasar': { 'Denpasar Selatan': ['Sanur', 'Panjer'], 'Denpasar Barat': ['Pemecutan', 'Dauh Puri'] },
  },
}

// Format angka gaya Indonesia: 1920 -> "1.920"
export const fmt = (n) => new Intl.NumberFormat('id-ID').format(Math.round(n))
