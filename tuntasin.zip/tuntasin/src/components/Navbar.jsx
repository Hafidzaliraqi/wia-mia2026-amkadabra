// NAVBAR: bar navigasi atas (logo, menu, tombol Login/Registrasi).
// - Sticky: tetap di atas saat scroll, dan muncul bayangan setelah di-scroll.
// - Responsif: di layar kecil menu berubah jadi tombol hamburger yang membuka panel.
import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom'
import { SearchIcon, MenuIcon, XIcon } from './Icons.jsx'

const LINKS = [
  { to: '/tentang', label: 'Tentang' },
  { to: '/rating', label: 'Rating' },
  { to: '/statistik', label: 'Statistik' },
  { to: '/pengaduan-tuntas', label: 'Pengaduan Tuntas' },
  { to: '/cari-laporan', label: 'Cari Laporan' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { pathname } = useLocation()
  const navigate = useNavigate()

  // Tutup menu mobile setiap pindah halaman
  useEffect(() => setOpen(false), [pathname])

  // Beri bayangan saat halaman di-scroll
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header className={`navbar ${scrolled ? 'is-scrolled' : ''}`}>
      <div className="container navbar-inner">
        <div className="brand-wrap">
          <button className="icon-circle" aria-label="Cari laporan" onClick={() => navigate('/cari-laporan')}>
            <SearchIcon size={16} />
          </button>
          <Link to="/" className="brand" aria-label="Tuntasin — beranda">
            tuntasin<span>.</span>
          </Link>
        </div>

        <nav className="nav-links" aria-label="Menu utama">
          {LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} className={({ isActive }) => (isActive ? 'active' : '')}>
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="nav-actions">
          <NavLink to="/login" className={({ isActive }) => `nav-login ${isActive ? 'active' : ''}`}>Login</NavLink>
          <Link to="/registrasi" className="btn btn-primary btn-sm">Registrasi</Link>
        </div>

        <button className="hamburger" aria-label={open ? 'Tutup menu' : 'Buka menu'} aria-expanded={open} onClick={() => setOpen((v) => !v)}>
          {open ? <XIcon size={20} /> : <MenuIcon size={20} />}
        </button>
      </div>

      {/* Panel menu untuk layar kecil */}
      <div className={`mobile-panel ${open ? 'open' : ''}`}>
        <div className="container">
          {LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} className={({ isActive }) => (isActive ? 'active' : '')}>
              {l.label}
            </NavLink>
          ))}
          <div className="mobile-actions">
            <Link to="/login" className="btn btn-ghost">Login</Link>
            <Link to="/registrasi" className="btn btn-primary">Registrasi</Link>
          </div>
        </div>
      </div>
    </header>
  )
}
