// PHOTO: gambar ilustrasi. Bila `src` diberikan, memakai foto asli; bila tidak, menggambar
// ilustrasi SVG sederhana (jalan/trotoar + pohon) sebagai pengganti foto di desain.
// >>> Untuk memakai foto asli: <Photo src="/foto/trotoar.jpg" alt="..." />
export default function Photo({ src, alt = '', scene = 'street', className = '' }) {
  if (src) return <img className={`photo ${className}`} src={src} alt={alt} loading="lazy" />

  const tone = scene === 'sidewalk'
    ? { sky1: '#dfe9e4', sky2: '#f4f0e6', ground: '#cfc9bd', path: '#e6dfcf', tree: '#4f7a46', tree2: '#6d9660' }
    : { sky1: '#e4ebe2', sky2: '#f2eee3', ground: '#b9b3a5', path: '#d9d0bd', tree: '#527a4a', tree2: '#7a9f68' }

  return (
    <div className={`photo photo-svg ${className}`} role="img" aria-label={alt}>
      <svg viewBox="0 0 400 260" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
        <defs>
          <linearGradient id={`sky-${scene}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={tone.sky1} />
            <stop offset="1" stopColor={tone.sky2} />
          </linearGradient>
        </defs>
        <rect width="400" height="260" fill={`url(#sky-${scene})`} />
        {/* bangunan di kejauhan */}
        <rect x="20" y="95" width="70" height="70" fill="#c9a98a" opacity=".75" />
        <rect x="290" y="85" width="90" height="80" fill="#d8c3a5" opacity=".8" />
        <polygon points="14,95 55,66 96,95" fill="#a8654a" opacity=".8" />
        {/* pohon */}
        <circle cx="70" cy="90" r="46" fill={tone.tree} />
        <circle cx="120" cy="80" r="38" fill={tone.tree2} />
        <circle cx="330" cy="82" r="48" fill={tone.tree} />
        <circle cx="280" cy="96" r="34" fill={tone.tree2} />
        <rect x="66" y="120" width="8" height="60" fill="#5b4636" />
        <rect x="326" y="120" width="8" height="60" fill="#5b4636" />
        {/* tanah & jalur */}
        <rect y="165" width="400" height="95" fill={tone.ground} />
        <polygon points="150,165 250,165 340,260 60,260" fill={tone.path} />
        <polygon points="196,165 204,165 215,260 185,260" fill="#e1b84a" opacity=".85" />
        {/* orang berjalan */}
        <circle cx="168" cy="182" r="5" fill="#8a5a44" /><rect x="164" y="187" width="8" height="20" rx="3" fill="#b92b3f" />
        <circle cx="232" cy="180" r="5" fill="#8a5a44" /><rect x="228" y="185" width="8" height="22" rx="3" fill="#3f5f8f" />
      </svg>
    </div>
  )
}
