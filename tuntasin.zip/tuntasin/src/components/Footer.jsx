// FOOTER: bagian bawah gelap yang sama di semua halaman (logo, tagline, tautan, catatan data simulasi).
import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-top">
          <div>
            <div className="brand brand-light">tuntasin.</div>
            <p className="footer-tag">Suaramu berarti. Tuntas jadi tujuan.</p>
          </div>
          <nav className="footer-links" aria-label="Tautan footer">
            <Link to="/tentang">Pusat bantuan</Link>
            <Link to="/tentang">Kebijakan privasi</Link>
            <Link to="/tentang">Syarat penggunaan</Link>
          </nav>
        </div>
        <div className="footer-bottom">
          <span>© 2026 Tuntasin. Ruang bersama untuk perubahan.</span>
          <span>Data simulasi untuk ilustrasi desain. Bukan data resmi pemerintah.</span>
        </div>
      </div>
    </footer>
  )
}
