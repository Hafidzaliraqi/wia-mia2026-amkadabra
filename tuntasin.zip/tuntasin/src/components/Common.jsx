// COMMON: komponen kecil yang dipakai ulang — Badge status, Select, Toast, dan Stepper alur 5 tahap.
import { useEffect } from 'react'
import { CheckCircleIcon, ChevronDownIcon, InfoIcon } from './Icons.jsx'

// Lencana hijau "Tuntas"
export function StatusBadge({ children = 'Tuntas' }) {
  return (
    <span className="badge-done">
      <CheckCircleIcon size={13} />
      {children}
    </span>
  )
}

// Dropdown bergaya (select bawaan browser + ikon panah) — mudah dipakai & aksesibel
export function Select({ id, label, value, onChange, options, placeholder, disabled, error, required }) {
  return (
    <div className="field">
      {label && (
        <label htmlFor={id}>
          {label}
          {required && ' *'}
        </label>
      )}
      <div className={`select-wrap ${error ? 'has-error' : ''}`}>
        <select id={id} value={value} onChange={(e) => onChange(e.target.value)} disabled={disabled} aria-invalid={!!error}>
          {placeholder && <option value="">{placeholder}</option>}
          {options.map((o) => {
            const v = typeof o === 'string' ? o : o.value
            const l = typeof o === 'string' ? o : o.label
            return (
              <option key={v} value={v}>
                {l}
              </option>
            )
          })}
        </select>
        <ChevronDownIcon size={16} />
      </div>
      {error && <p className="field-error">{error}</p>}
    </div>
  )
}

// Notifikasi kecil yang hilang sendiri
export function Toast({ message, onClose }) {
  useEffect(() => {
    if (!message) return
    const t = setTimeout(onClose, 3200)
    return () => clearTimeout(t)
  }, [message, onClose])
  return (
    <div className={`toast ${message ? 'show' : ''}`} role="status" aria-live="polite">
      <InfoIcon size={16} />
      <span>{message}</span>
    </div>
  )
}

// Alur 5 tahap: Dikirim → Verifikasi → Tindak lanjut → Tanggapan → Tuntas
export const STEPS = [
  { t: 'Dikirim', d: 'Ceritakan masalah, pilih lokasi, dan lampirkan bukti.' },
  { t: 'Verifikasi', d: 'Kelengkapan laporan diperiksa sebelum diteruskan.' },
  { t: 'Tindak lanjut', d: 'Laporan diteruskan ke pihak terkait untuk ditangani.' },
  { t: 'Tanggapan', d: 'Lihat respons dan bukti penanganan di akunmu.' },
  { t: 'Tuntas', d: 'Konfirmasi hasilnya. Masalah selesai, perubahan terasa.' },
]

export function Stepper({ active = 0 }) {
  return (
    <ol className="stepper">
      {STEPS.map((s, i) => (
        <li key={s.t} className={i <= active ? 'on' : ''}>
          <div className="step-head">
            <span className="step-num">{String(i + 1).padStart(2, '0')}</span>
            <span className="step-line" />
          </div>
          <h4>{s.t}</h4>
          <p>{s.d}</p>
        </li>
      ))}
    </ol>
  )
}
