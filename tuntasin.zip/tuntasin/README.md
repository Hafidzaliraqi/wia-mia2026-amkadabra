# Tuntasin — Frontend React

Frontend ruang pengaduan publik "Tuntasin" (React 18 + Vite + React Router). Halaman 1 di PDF (beranda) sengaja tidak dibuat.

## Menjalankan

```bash
npm install
npm run dev      # buka http://localhost:5173
npm run build    # hasil produksi di folder dist/
```

## Peta kode: file ini untuk bagian apa?

| File | Fungsi / bagian desain |
|---|---|
| `index.html` | Kerangka HTML, memuat font Inter |
| `src/main.jsx` | Titik awal aplikasi + router |
| `src/App.jsx` | Daftar rute (URL → halaman), Navbar & Footer bersama, scroll ke atas tiap pindah halaman |
| `src/styles.css` | Semua styling (warna, layout, komponen, responsif), dibagi per bagian bernomor |
| `src/data.js` | Data simulasi (angka statistik, daftar laporan, wilayah). Ganti dengan API nanti |
| `src/components/Navbar.jsx` | Bar navigasi atas, sticky, menu hamburger di mobile |
| `src/components/Footer.jsx` | Footer gelap |
| `src/components/Reveal.jsx` | Animasi muncul halus saat di-scroll |
| `src/components/Photo.jsx` | Gambar ilustrasi (pengganti foto). Beri prop `src` untuk foto asli |
| `src/components/Common.jsx` | Lencana "Tuntas", dropdown Select, Toast, Stepper 5 tahap |
| `src/components/Icons.jsx` | Semua ikon SVG |
| `src/pages/Login.jsx` | Halaman Login (`/login`) |
| `src/pages/Register.jsx` | Halaman Registrasi (`/registrasi`) |
| `src/pages/Submit.jsx` | Halaman Ajukan Pengaduan (`/ajukan`) |
| `src/pages/Stats.jsx` | Halaman Statistik (`/statistik`) |
| `src/pages/Resolved.jsx` | Halaman Pengaduan Tuntas (`/pengaduan-tuntas`) |
| `src/pages/SearchReports.jsx` | Halaman Cari Laporan (`/cari-laporan`) |

## Catatan

- `/` dialihkan ke `/pengaduan-tuntas`; menu Tentang dan Rating memakai halaman sementara karena belum ada di desain.
- Login, registrasi, dan kirim pengaduan masih simulasi (belum ada backend). Titik penyambungan API ditandai komentar `Simulasi`.
- Semua foto adalah ilustrasi SVG; ganti dengan foto asli lewat prop `src` pada `<Photo />`.
